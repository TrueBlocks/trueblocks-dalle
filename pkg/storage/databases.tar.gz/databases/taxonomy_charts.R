#!/usr/bin/env Rscript
library(ggplot2)

# Read all hierarchy files
nouns <- read.csv("nouns.csv", stringsAsFactors=FALSE)
families_df <- read.csv("families.csv", stringsAsFactors=FALSE)
orders_df <- read.csv("orders.csv", stringsAsFactors=FALSE)
classes_df <- read.csv("classes.csv", stringsAsFactors=FALSE)

# Walk chain: noun -> family -> order -> class -> phylum
merged <- merge(nouns, families_df[,c("family","order","commonName")], by="family", all.x=TRUE, suffixes=c("",".fam"))
names(merged)[names(merged)=="commonName.fam"] <- "familyCommon"
names(merged)[names(merged)=="order"] <- "orderName"
merged <- merge(merged, orders_df[,c("order","class","commonName")], by.x="orderName", by.y="order", all.x=TRUE, suffixes=c("",".ord"))
names(merged)[names(merged)=="commonName"] <- "orderCommon"
names(merged)[names(merged)=="class"] <- "className"
merged <- merge(merged, classes_df[,c("class","phylum","commonName")], by.x="className", by.y="class", all.x=TRUE, suffixes=c("",".cls"))
names(merged)[names(merged)=="commonName"] <- "classCommon"

# --- Chart 1: Phylum distribution ---
phylum_counts <- as.data.frame(table(merged$phylum))
names(phylum_counts) <- c("phylum", "count")
phylum_counts <- phylum_counts[order(-phylum_counts$count),]
phylum_counts$phylum <- factor(phylum_counts$phylum, levels=phylum_counts$phylum)

p1 <- ggplot(phylum_counts, aes(x=phylum, y=count)) +
  geom_bar(stat="identity", fill="steelblue") +
  coord_flip() +
  labs(title="Nouns by Phylum", x="", y="Count") +
  theme_minimal(base_size=11)
ggsave("/tmp/taxonomy_phyla.png", p1, width=8, height=6, dpi=150)

# --- Chart 2: Class distribution (top 15) ---
class_counts <- as.data.frame(table(merged$className))
names(class_counts) <- c("class", "count")
class_counts <- class_counts[order(-class_counts$count),]
class_counts <- head(class_counts, 15)
class_counts$class <- factor(class_counts$class, levels=class_counts$class)

p2 <- ggplot(class_counts, aes(x=class, y=count)) +
  geom_bar(stat="identity", fill="darkorange") +
  coord_flip() +
  labs(title="Nouns by Class (top 15)", x="", y="Count") +
  theme_minimal(base_size=11)
ggsave("/tmp/taxonomy_classes.png", p2, width=8, height=6, dpi=150)

# --- Chart 3: Order distribution (top 20) ---
order_counts <- as.data.frame(table(merged$orderName))
names(order_counts) <- c("order", "count")
order_counts <- order_counts[order(-order_counts$count),]
order_counts <- head(order_counts, 20)
order_counts$order <- factor(order_counts$order, levels=order_counts$order)

p3 <- ggplot(order_counts, aes(x=order, y=count)) +
  geom_bar(stat="identity", fill="forestgreen") +
  coord_flip() +
  labs(title="Nouns by Order (top 20)", x="", y="Count") +
  theme_minimal(base_size=11)
ggsave("/tmp/taxonomy_orders.png", p3, width=8, height=7, dpi=150)

# --- Chart 4: Family distribution (top 30) ---
family_counts <- as.data.frame(table(merged$family))
names(family_counts) <- c("family", "count")
family_counts <- family_counts[order(-family_counts$count),]
family_counts <- head(family_counts, 30)
family_counts$family <- factor(family_counts$family, levels=family_counts$family)

p4 <- ggplot(family_counts, aes(x=family, y=count)) +
  geom_bar(stat="identity", fill="firebrick") +
  geom_hline(yintercept=60, linetype="dashed", color="blue", linewidth=0.8) +
  annotate("text", x=5, y=65, label="proposed cap (60)", color="blue", size=3.5) +
  coord_flip() +
  labs(title="Nouns by Family (top 30) — blue line = proposed cap", x="", y="Count") +
  theme_minimal(base_size=10)
ggsave("/tmp/taxonomy_families.png", p4, width=8, height=8, dpi=150)

cat("Charts saved to /tmp/taxonomy_*.png\n")
